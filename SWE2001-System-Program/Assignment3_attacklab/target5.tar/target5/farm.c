/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_465()
{
    return 3284633932U;
}

void setval_137(unsigned *p)
{
    *p = 2428995912U;
}

void setval_365(unsigned *p)
{
    *p = 2462550344U;
}

void setval_123(unsigned *p)
{
    *p = 2425378824U;
}

unsigned addval_307(unsigned x)
{
    return x + 3281016985U;
}

unsigned getval_165()
{
    return 3468906606U;
}

unsigned addval_115(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_273(unsigned x)
{
    return x + 2438463492U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_154(unsigned *p)
{
    *p = 3676361097U;
}

void setval_377(unsigned *p)
{
    *p = 3526935181U;
}

unsigned getval_239()
{
    return 3252717896U;
}

unsigned addval_416(unsigned x)
{
    return x + 3269495112U;
}

unsigned getval_248()
{
    return 415486217U;
}

unsigned getval_339()
{
    return 3247493513U;
}

void setval_498(unsigned *p)
{
    *p = 3232026249U;
}

unsigned getval_386()
{
    return 3674788265U;
}

void setval_212(unsigned *p)
{
    *p = 3286272456U;
}

void setval_464(unsigned *p)
{
    *p = 3675836041U;
}

unsigned getval_150()
{
    return 3536110217U;
}

unsigned getval_352()
{
    return 2430634312U;
}

void setval_252(unsigned *p)
{
    *p = 3523268233U;
}

void setval_271(unsigned *p)
{
    *p = 3525365449U;
}

unsigned getval_402()
{
    return 3529560457U;
}

unsigned addval_395(unsigned x)
{
    return x + 3532964489U;
}

void setval_280(unsigned *p)
{
    *p = 3769190527U;
}

void setval_430(unsigned *p)
{
    *p = 3383021193U;
}

unsigned getval_285()
{
    return 3374371209U;
}

unsigned getval_438()
{
    return 3523792521U;
}

unsigned addval_378(unsigned x)
{
    return x + 3348152969U;
}

unsigned getval_270()
{
    return 3286272332U;
}

unsigned addval_152(unsigned x)
{
    return x + 3281044105U;
}

unsigned getval_403()
{
    return 3286272329U;
}

void setval_136(unsigned *p)
{
    *p = 3536113289U;
}

unsigned getval_302()
{
    return 3286272328U;
}

unsigned getval_258()
{
    return 3674784393U;
}

unsigned addval_325(unsigned x)
{
    return x + 2445445396U;
}

void setval_497(unsigned *p)
{
    *p = 3227566729U;
}

unsigned addval_453(unsigned x)
{
    return x + 3682913929U;
}

void setval_279(unsigned *p)
{
    *p = 3682914569U;
}

unsigned getval_407()
{
    return 3525366025U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
